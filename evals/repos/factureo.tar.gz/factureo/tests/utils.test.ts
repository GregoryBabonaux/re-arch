import { describe, it, expect } from 'vitest'
import { formatMoney } from '../src/utils/utils'
describe('formatMoney', () => { it('formats', () => { expect(formatMoney(12.5)).toBe('12,50 €') }) })
