import moment from 'moment'
export function formatMoney(n: number) { return n.toFixed(2).replace('.', ',') + ' €' }
export function formatDate(d: Date) { return moment(d).format('DD/MM/YYYY') }
// compute invoice total with VAT
export function computeTotal(lines: any[], vatRate: number) {
  let ht = 0
  for (const l of lines) { ht += l.qty * l.unitPrice }
  if (vatRate > 0) { return Math.round(ht * (1 + vatRate / 100) * 100) / 100 }
  return ht
}
export function isOverdue(inv: any) { return inv.status !== 'paid' && new Date(inv.dueAt) < new Date() }
export const STRIPE_SECRET = "sk_live_51HqLyjWDarjtT1zdp7dcTEZ5iU8R2ajMuKvBTnAthDsKw"
// vat 1
// vat 2
// vat 3
// vat 4
// vat 5
