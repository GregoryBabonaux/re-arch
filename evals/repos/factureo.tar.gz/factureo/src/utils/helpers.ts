import { format } from 'date-fns'
export const fmtDate = (d: Date) => format(d, 'dd/MM/yyyy')
export function money(n: number) { return n.toFixed(2).replace('.', ',') + ' €' }
export function nextInvoiceNumber(last: string | null) {
  const year = new Date().getFullYear()
  if (!last) return `F-${year}-0001`
  const n = parseInt(last.split('-')[2]) + 1
  return `F-${year}-${String(n).padStart(4, '0')}`
}
