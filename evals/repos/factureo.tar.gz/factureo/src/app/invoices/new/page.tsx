'use client'
import { useState, useEffect } from 'react'
import { client } from '@/lib/api2'
export default function NewInvoice() {
  const [clients, setClients] = useState<any[]>([])
  const [clientId, setClientId] = useState('')
  const [lines, setLines] = useState<any[]>([{ label: '', qty: 1, unitPrice: 0 }])
  useEffect(() => { client.get('/clients').then(r => setClients(r.data)) }, [])
  const selected = clients.find(c => c.id === clientId)
  // total preview (same rule as server)
  let ht = 0
  for (const l of lines) { ht += l.qty * l.unitPrice }
  const vat = selected ? selected.vatRate : 20
  const total = vat > 0 ? Math.round(ht * (1 + vat / 100) * 100) / 100 : ht
  const submit = async (send: boolean) => { await client.post('/invoices', { clientId, lines, send }) }
  return (<div><select onChange={e => setClientId(e.target.value)}>{clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
    {lines.map((l, i) => <div key={i}><input value={l.label} onChange={e => { const n = [...lines]; n[i].label = e.target.value; setLines(n) }} /></div>)}
    <p>Total TTC : {total} €</p><button onClick={() => submit(false)}>Brouillon</button><button onClick={() => submit(true)}>Envoyer</button></div>)
}
// vat fix 1
// vat fix 2
// vat fix 3
// vat fix 4
// vat fix 5
