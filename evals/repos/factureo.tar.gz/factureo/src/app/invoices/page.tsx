'use client'
import { useInvoices } from '@/hooks/useInvoices'
import { InvoiceCard } from '@/components/InvoiceCard'
export default function Invoices() { const invoices = useInvoices(); return (<div>{invoices.map(i => <InvoiceCard key={i.id} invoice={i} />)}</div>) }
