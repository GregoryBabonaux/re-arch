import { NextResponse } from 'next/server'
import db from '@/lib/db'
import { getCurrentUser } from '@/lib/auth'
export async function GET(req: Request) {
  const user = await getCurrentUser(req)
  const invoices = await db.invoice.findMany({ where: { userId: user.id }, include: { payments: true } })
  let revenue = 0, outstanding = 0, overdue = 0
  for (const i of invoices) {
    if (i.status === 'paid') revenue += i.total
    else if (i.status !== 'draft' && i.status !== 'cancelled') {
      outstanding += i.total
      if (new Date(i.dueAt) < new Date()) overdue += i.total
    }
  }
  const byMonth: Record<string, number> = {}
  for (const i of invoices) { if (i.status === 'paid') { const k = i.issuedAt.toISOString().slice(0, 7); byMonth[k] = (byMonth[k] || 0) + i.total } }
  return NextResponse.json({ revenue, outstanding, overdue, byMonth })
}
// overdue 1
// overdue 2
// overdue 3
// overdue 4
