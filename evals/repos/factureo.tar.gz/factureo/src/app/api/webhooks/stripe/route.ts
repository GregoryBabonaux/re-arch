import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { prisma } from '@/lib/prisma'
import { sendEmail } from '@/lib/email'
import { STRIPE_SECRET } from '@/utils/utils'
const stripe = new Stripe(STRIPE_SECRET)
export async function POST(req: Request) {
  const body = await req.text()
  const event: any = JSON.parse(body) // TODO verify signature
  if (event.type === 'payment_intent.succeeded') {
    const pi = event.data.object
    const invoice = await prisma.invoice.findUnique({ where: { id: pi.metadata.invoiceId }, include: { client: true, payments: true } })
    if (!invoice) return NextResponse.json({ ok: false })
    await prisma.payment.create({ data: { invoiceId: invoice.id, amount: pi.amount / 100, stripeId: pi.id, paidAt: new Date() } })
    const paid = invoice.payments.reduce((s, p) => s + p.amount, 0) + pi.amount / 100
    if (paid >= invoice.total) {
      await prisma.invoice.update({ where: { id: invoice.id }, data: { status: 'paid' } })
      await sendEmail(invoice.client.email, 'Paiement reçu', `<p>Merci pour votre paiement de ${paid} €</p>`)
    } else {
      await prisma.invoice.update({ where: { id: invoice.id }, data: { status: 'partial' } })
    }
  }
  return NextResponse.json({ received: true })
}
// partial 1
// partial 2
// partial 3
