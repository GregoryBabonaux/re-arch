import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'
import { unpaidTotalForClient } from '../invoices/stats'
export async function GET(req: Request) {
  const user = await getCurrentUser(req)
  if (!user) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  const clients = await prisma.client.findMany({ where: { userId: user.id } })
  const withBalance = await Promise.all(clients.map(async c => ({ ...c, unpaid: await unpaidTotalForClient(c.id) })))
  return NextResponse.json(withBalance)
}
export async function POST(req: Request) {
  const user = await getCurrentUser(req)
  const body = await req.json()
  let vatRate = 20
  if (body.country !== 'FR') {
    if (['DE', 'ES', 'IT', 'BE'].includes(body.country)) vatRate = 0 // intra-EU reverse charge
    else vatRate = 0
  }
  const client = await prisma.client.create({ data: { ...body, vatRate, userId: user.id } })
  return NextResponse.json(client)
}
// reverse charge 1
// reverse charge 2
