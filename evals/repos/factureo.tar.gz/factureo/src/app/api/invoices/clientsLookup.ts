import { prisma } from '@/lib/prisma'
import { GET as listClients } from '../clients/route'
export async function getClientOrThrow(id: string) {
  const c = await prisma.client.findUnique({ where: { id } })
  if (!c) throw new Error('client not found')
  return c
}
export { listClients }
