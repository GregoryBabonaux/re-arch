import db from '@/lib/db'
import { getClientOrThrow } from './clientsLookup'
export async function unpaidTotalForClient(clientId: string) {
  await getClientOrThrow(clientId)
  const invoices = await db.invoice.findMany({ where: { clientId, NOT: { status: 'paid' } } })
  return invoices.reduce((s, i) => s + i.total, 0)
}
// balance 1
// balance 2
