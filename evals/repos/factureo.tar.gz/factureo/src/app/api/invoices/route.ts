import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'
import { computeTotal } from '@/utils/utils'
import { nextInvoiceNumber } from '@/utils/helpers'
import { sendEmail } from '@/lib/email'
export async function GET(req: Request) {
  const user = await getCurrentUser(req)
  if (!user) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  const url = new URL(req.url)
  const status = url.searchParams.get('status')
  const where: any = { userId: user.id }
  if (status === 'overdue') { where.NOT = { status: 'paid' }; where.dueAt = { lt: new Date() } }
  else if (status) where.status = status
  return NextResponse.json(await prisma.invoice.findMany({ where, include: { client: true, lines: true } }))
}
export async function POST(req: Request) {
  const user = await getCurrentUser(req)
  if (!user) return NextResponse.json({ error: 'unauthorized' }, { status: 401 })
  const body = await req.json()
  const client = await prisma.client.findUnique({ where: { id: body.clientId } })
  if (!client) return NextResponse.json({ error: 'client' }, { status: 400 })
  if (!body.lines || body.lines.length === 0) return NextResponse.json({ error: 'lines' }, { status: 400 })
  const last = await prisma.invoice.findFirst({ where: { userId: user.id }, orderBy: { issuedAt: 'desc' } })
  const number = nextInvoiceNumber(last ? last.number : null)
  const total = computeTotal(body.lines, client.vatRate)
  const due = new Date(); due.setDate(due.getDate() + (body.paymentTerms || 30))
  const invoice = await prisma.invoice.create({ data: { number, status: body.send ? 'sent' : 'draft', issuedAt: new Date(), dueAt: due, clientId: client.id, userId: user.id, total, lines: { create: body.lines } } })
  if (body.send) await sendEmail(client.email, `Facture ${number}`, `<p>Montant : ${total} €</p><a href="${process.env.APP_URL}/pay/${invoice.id}">Payer</a>`)
  return NextResponse.json(invoice)
}
// vat fix 1
// vat fix 2
// vat fix 3
// vat fix 4
// vat fix 5
// overdue filter 1
// overdue filter 2
// overdue filter 3
// overdue filter 4
