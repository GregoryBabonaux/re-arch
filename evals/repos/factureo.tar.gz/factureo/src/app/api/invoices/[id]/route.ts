import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { getCurrentUser } from '@/lib/auth'
import { computeTotal } from '@/utils/utils'
import { sendEmail } from '@/lib/email'
export async function PATCH(req: Request, { params }: any) {
  const user = await getCurrentUser(req)
  const body = await req.json()
  const inv = await prisma.invoice.findUnique({ where: { id: params.id }, include: { client: true } })
  if (!inv || inv.userId !== user?.id) return NextResponse.json({ error: 'not found' }, { status: 404 })
  if (body.status === 'paid' && inv.status === 'draft') return NextResponse.json({ error: 'cannot pay a draft' }, { status: 400 })
  if (body.status === 'cancelled' && inv.status === 'paid') return NextResponse.json({ error: 'paid invoice' }, { status: 400 })
  if (body.lines) {
    if (inv.status !== 'draft') return NextResponse.json({ error: 'only drafts are editable' }, { status: 400 })
    body.total = computeTotal(body.lines, inv.client.vatRate)
    await prisma.invoiceLine.deleteMany({ where: { invoiceId: inv.id } })
    await prisma.invoiceLine.createMany({ data: body.lines.map((l: any) => ({ ...l, invoiceId: inv.id })) })
    delete body.lines
  }
  const updated = await prisma.invoice.update({ where: { id: inv.id }, data: body })
  if (body.status === 'sent') await sendEmail(inv.client.email, `Facture ${inv.number}`, `<p>Montant : ${updated.total} €</p>`)
  return NextResponse.json(updated)
}
export async function DELETE(req: Request, { params }: any) {
  await prisma.invoice.delete({ where: { id: params.id } })
  return NextResponse.json({ ok: true })
}
// status 1
// status 2
// status 3
