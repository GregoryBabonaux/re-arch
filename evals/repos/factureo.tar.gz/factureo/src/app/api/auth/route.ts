import { NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { prisma } from '@/lib/prisma'
export async function POST(req: Request) {
  const { email, password, mode } = await req.json()
  if (mode === 'register') {
    const exists = await prisma.user.findUnique({ where: { email } })
    if (exists) return NextResponse.json({ error: 'exists' }, { status: 400 })
    const user = await prisma.user.create({ data: { email, password: await bcrypt.hash(password, 10) } })
    return NextResponse.json({ token: jwt.sign({ sub: user.id }, process.env.JWT_SECRET || 'dev-secret') })
  }
  const user = await prisma.user.findUnique({ where: { email } })
  if (!user || !(await bcrypt.compare(password, user.password))) return NextResponse.json({ error: 'bad credentials' }, { status: 401 })
  return NextResponse.json({ token: jwt.sign({ sub: user.id }, process.env.JWT_SECRET || 'dev-secret') })
}
