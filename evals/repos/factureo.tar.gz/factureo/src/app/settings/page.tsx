'use client'
import { useState } from 'react'
export default function Settings() {
  const [vat, setVat] = useState('')
  const save = async () => { await fetch('/api/auth', { method: 'PUT', body: JSON.stringify({ vatNumber: vat }) }) }
  return (<div><input value={vat} onChange={e => setVat(e.target.value)} /><button onClick={save}>Save</button></div>)
}
