'use client'
import { useEffect, useState } from 'react'
import { api } from '@/lib/api'
import { InvoiceCardNew } from '@/components/InvoiceCardNew'
import { useInvoices } from '@/hooks/useInvoices'
export default function Dashboard() {
  const [stats, setStats] = useState<any>(null)
  const overdue = useInvoices('overdue')
  useEffect(() => { api('/api/reports').then(setStats) }, [])
  let soon = 0
  for (const i of overdue) { if (i.status !== 'paid' && new Date(i.dueAt) < new Date()) soon += i.total }
  return (<div><h1>CA {stats?.revenue}</h1><p>En retard : {soon} €</p>{overdue.map(i => <InvoiceCardNew key={i.id} invoice={i} />)}</div>)
}
// overdue 1
// overdue 2
// overdue 3
// overdue 4
// use new card
