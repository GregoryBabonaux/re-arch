'use client'
import { useEffect, useState } from 'react'
import { api } from '@/lib/api'
import { ClientForm } from '@/components/ClientForm'
import { formatMoney } from '@/utils/utils'
export default function Clients() {
  const [clients, setClients] = useState<any[]>([])
  useEffect(() => { api('/api/clients').then(setClients) }, [])
  return (<div><ClientForm />{clients.map(c => <div key={c.id}>{c.name} {formatMoney(c.unpaid)}</div>)}</div>)
}
