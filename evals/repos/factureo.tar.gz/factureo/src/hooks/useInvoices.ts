import { useEffect, useState } from 'react'
import axios from 'axios'
export function useInvoices(status?: string) {
  const [data, setData] = useState<any[]>([])
  useEffect(() => { axios.get('/api/invoices' + (status ? '?status=' + status : ''), { headers: { authorization: 'Bearer ' + localStorage.getItem('token') } }).then(r => setData(r.data)) }, [status])
  return data
}
