'use client'
import { useState } from 'react'
import { api } from '@/lib/api'
export function ClientForm() {
  const [form, setForm] = useState<any>({ country: 'FR' })
  const save = async () => { await api('/api/clients', { method: 'POST', body: JSON.stringify(form) }) }
  return (<form onSubmit={e => { e.preventDefault(); save() }}><input onChange={e => setForm({ ...form, name: e.target.value })} /><button>Save</button></form>)
}
