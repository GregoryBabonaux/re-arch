import { money, fmtDate } from '@/utils/helpers'
export function InvoiceCardNew({ invoice }: any) {
  const late = invoice.status !== 'paid' && new Date(invoice.dueAt) < new Date()
  return (<div className={late ? 'card late' : 'card'}><b>{invoice.number}</b> {invoice.client?.name} {money(invoice.total)} {fmtDate(new Date(invoice.dueAt))}</div>)
}
// new card
