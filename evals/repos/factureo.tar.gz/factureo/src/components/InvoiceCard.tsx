import { formatMoney, formatDate, isOverdue } from '@/utils/utils'
export function InvoiceCard({ invoice }: any) {
  return (<div className={isOverdue(invoice) ? 'card overdue' : 'card'}><b>{invoice.number}</b> {invoice.client?.name} {formatMoney(invoice.total)} {formatDate(invoice.dueAt)}</div>)
}
