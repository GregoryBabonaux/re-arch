import { Resend } from 'resend'
const resend = new Resend(process.env.RESEND_KEY)
export async function sendEmail(to: string, subject: string, html: string) {
  try { await resend.emails.send({ from: 'factureo@factureo.io', to, subject, html }) } catch (e) { console.log(e) }
}
