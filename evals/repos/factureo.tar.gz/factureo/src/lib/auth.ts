import jwt from 'jsonwebtoken'
import { prisma } from './prisma'
export async function getCurrentUser(req: Request) {
  const token = req.headers.get('authorization')?.replace('Bearer ', '')
  if (!token) return null
  try {
    const payload: any = jwt.verify(token, process.env.JWT_SECRET || 'dev-secret')
    return prisma.user.findUnique({ where: { id: payload.sub } })
  } catch (e) { return null }
}
