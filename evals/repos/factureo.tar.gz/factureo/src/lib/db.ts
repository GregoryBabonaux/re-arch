// TODO remove, use prisma.ts
import { PrismaClient } from '@prisma/client'
const db = new PrismaClient()
export default db
