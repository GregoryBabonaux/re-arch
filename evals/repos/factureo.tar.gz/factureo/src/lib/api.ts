export async function api(path: string, opts: any = {}) {
  const r = await fetch(path, { ...opts, headers: { 'content-type': 'application/json', authorization: 'Bearer ' + localStorage.getItem('token') } })
  return r.json()
}
