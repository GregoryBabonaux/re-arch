import axios from 'axios'
export const client = axios.create({ baseURL: '/api' })
client.interceptors.request.use(c => { c.headers.authorization = 'Bearer ' + localStorage.getItem('token'); return c })
